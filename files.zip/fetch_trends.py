"""
Google Trends 자동 수집 스크립트
─────────────────────────────────
data/keywords.json 에 정의된 키워드들의 트렌드 데이터를 fetch
data/trends.json 에 저장. GitHub Actions cron에서 실행됨.

사용법:
  python scripts/fetch_trends.py

요구사항:
  pip install pytrends pandas

특이사항:
  - pytrends는 비공식 라이브러리. 너무 자주/많이 호출하면 429(Too Many Requests) 발생.
  - 5개씩 batch 단위로 호출, 각 batch 사이 SLEEP_SECONDS 대기.
  - 키워드 한 batch가 실패해도 전체 진행 계속, 마지막에 실패 목록 출력.
  - 차단되면 SerpApi 등 유료 대안으로 전환 권장 (SETUP 가이드 참조).
"""
from __future__ import annotations

import json
import sys
import time
from datetime import datetime, timezone
from pathlib import Path

try:
    from pytrends.request import TrendReq
except ImportError:
    print("✗ pytrends 미설치. `pip install pytrends pandas` 실행 후 재시도.")
    sys.exit(1)

# ─── CONFIG ───
ROOT = Path(__file__).parent.parent
KEYWORDS_FILE = ROOT / "data" / "keywords.json"
OUTPUT_FILE = ROOT / "data" / "trends.json"

BATCH_SIZE = 5         # pytrends 한 번에 최대 5개 키워드
SLEEP_SECONDS = 4      # batch 간 대기 (rate limit 회피)
MAX_RETRIES = 2        # batch 실패 시 재시도 횟수
BACKOFF_SECONDS = 30   # 429 발생 시 대기


def flatten_keywords(keywords_data: dict) -> list[dict]:
    """카테고리 구조를 flat 리스트로 변환."""
    items = []
    for category, subcats in keywords_data.get("categories", {}).items():
        for subcategory, kw_list in subcats.items():
            for entry in kw_list:
                items.append({
                    "keyword": entry["keyword"],
                    "ticker": entry.get("ticker", ""),
                    "geo": entry.get("geo", ""),
                    "category": category,
                    "subcategory": subcategory,
                })
    return items


def fetch_batch(pytrends: TrendReq, keywords: list[str], geo: str, timeframe: str) -> dict | None:
    """5개 이하 키워드 batch fetch."""
    for attempt in range(MAX_RETRIES + 1):
        try:
            pytrends.build_payload(keywords, geo=geo, timeframe=timeframe)
            df = pytrends.interest_over_time()
            if df.empty:
                print(f"  ⚠ empty result for batch: {keywords}")
                return None
            if "isPartial" in df.columns:
                df = df.drop(columns=["isPartial"])
            return {
                "values": {kw: df[kw].tolist() for kw in keywords if kw in df.columns},
                "dates": [d.isoformat() for d in df.index.to_pydatetime()],
            }
        except Exception as e:
            err_str = str(e)
            print(f"  ✗ attempt {attempt + 1} failed: {err_str[:120]}")
            if "429" in err_str or "rate" in err_str.lower():
                print(f"  ⏸ rate limit hit, backing off {BACKOFF_SECONDS}s")
                time.sleep(BACKOFF_SECONDS)
            elif attempt < MAX_RETRIES:
                time.sleep(SLEEP_SECONDS * 2)
    return None


def compute_changes(values: list[float]) -> tuple[float, float, float]:
    """(yoyChange, wowChange, lastValue) 계산."""
    if not values:
        return 0.0, 0.0, 0.0
    last = values[-1]
    first = values[0] or 1
    yoy = ((last - first) / first) * 100
    wow = 0.0
    if len(values) >= 2:
        prev = values[-2] or 1
        wow = ((last - prev) / prev) * 100
    return round(yoy, 1), round(wow, 1), float(last)


def main() -> int:
    print(f"▶ Loading keywords from {KEYWORDS_FILE}")
    if not KEYWORDS_FILE.exists():
        print(f"✗ {KEYWORDS_FILE} not found")
        return 1

    keywords_data = json.loads(KEYWORDS_FILE.read_text(encoding="utf-8"))
    timeframe = keywords_data.get("defaultTimeframe", "today 12-m")

    items = flatten_keywords(keywords_data)
    print(f"  → {len(items)} keywords across {len(keywords_data['categories'])} categories")

    if not items:
        print("✗ no keywords to fetch")
        return 1

    # geo 별로 grouping (pytrends는 build_payload 호출 당 단일 geo만 지원)
    by_geo: dict[str, list[dict]] = {}
    for it in items:
        by_geo.setdefault(it["geo"], []).append(it)

    pytrends = TrendReq(hl="en-US", tz=540, retries=2, backoff_factor=0.5)
    results: list[dict] = []
    failed: list[str] = []

    for geo, geo_items in by_geo.items():
        geo_label = geo if geo else "WORLDWIDE"
        print(f"\n▶ Fetching geo={geo_label} ({len(geo_items)} keywords)")

        for i in range(0, len(geo_items), BATCH_SIZE):
            batch = geo_items[i:i + BATCH_SIZE]
            keywords = [b["keyword"] for b in batch]
            print(f"  [{i // BATCH_SIZE + 1}/{(len(geo_items) - 1) // BATCH_SIZE + 1}] {keywords}")

            response = fetch_batch(pytrends, keywords, geo, timeframe)

            if response is None:
                failed.extend(keywords)
            else:
                for item in batch:
                    kw = item["keyword"]
                    if kw not in response["values"]:
                        failed.append(kw)
                        continue
                    values = response["values"][kw]
                    yoy, wow, last = compute_changes(values)
                    results.append({
                        "keyword": kw,
                        "ticker": item["ticker"],
                        "geo": item["geo"],
                        "category": item["category"],
                        "subcategory": item["subcategory"],
                        "trendValues": values,
                        "trendDates": response["dates"],
                        "lastValue": last,
                        "yoyChange": yoy,
                        "wowChange": wow,
                    })

            time.sleep(SLEEP_SECONDS)

    # Preserve favorites from existing trends.json (don't lose user toggles)
    existing_favs: dict[str, dict] = {}
    if OUTPUT_FILE.exists():
        try:
            old = json.loads(OUTPUT_FILE.read_text(encoding="utf-8"))
            for d in old.get("data", []):
                if d.get("favorite") or d.get("favoriteRank"):
                    existing_favs[d["keyword"]] = {
                        "favorite": d.get("favorite", False),
                        "favoriteRank": d.get("favoriteRank"),
                    }
        except Exception:
            pass

    for r in results:
        if r["keyword"] in existing_favs:
            r.update(existing_favs[r["keyword"]])

    # Output
    output = {
        "metadata": {
            "lastUpdated": datetime.now(timezone.utc).isoformat(),
            "totalKeywords": len(results),
            "failedKeywords": failed,
            "source": "pytrends",
            "timeframe": timeframe,
        },
        "data": results,
    }

    OUTPUT_FILE.parent.mkdir(parents=True, exist_ok=True)
    OUTPUT_FILE.write_text(json.dumps(output, ensure_ascii=False, indent=2), encoding="utf-8")

    print(f"\n✓ Wrote {len(results)} entries to {OUTPUT_FILE}")
    if failed:
        print(f"⚠ {len(failed)} keywords failed: {failed[:10]}{'...' if len(failed) > 10 else ''}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
